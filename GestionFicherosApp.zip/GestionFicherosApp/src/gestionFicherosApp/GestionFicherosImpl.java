package gestionFicherosApp;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import gestionficheros.FormatoVistas;
import gestionficheros.GestionFicheros;
import gestionficheros.GestionFicherosException;
import gestionficheros.TipoOrden;

public class GestionFicherosImpl implements GestionFicheros {


	
	private File carpetaDeTrabajo = null;
	private Object[][] contenido;
	private int filas =0;
	private int columnas = 3;
	
	private FormatoVistas formatoVistas = FormatoVistas.NOMBRES;
	private TipoOrden ordenado = TipoOrden.DESORDENADO;

	
	public GestionFicherosImpl() {
		carpetaDeTrabajo = File.listRoots()[0];
		actualiza();
	}
	private void actualiza() {
		// TODO Auto-generated method stub
		String[] ficheros = carpetaDeTrabajo.list(); // obtener los nombres
		// calcular el n�mero de filas necesario
		filas = ficheros.length / columnas;
		if (filas * columnas < ficheros.length) {
			filas++; // si hay resto necesitamos una fila m�s
		}

		// dimensionar la matriz contenido seg�n los resultados

		contenido = new String[filas][columnas];
		// Rellenar contenido con los nombres obtenidos
		for (int i = 0; i < columnas; i++) {
			for (int j = 0; j < filas; j++) {
				int ind = j * columnas + i;
				if (ind < ficheros.length) {
					contenido[j][i] = ficheros[ind];
				} else {
					contenido[j][i] = "";
				}
			}
		}
	}
	@Override
	public void arriba() {
		// TODO Auto-generated method stub
		if(carpetaDeTrabajo.getParentFile() !=null)
		carpetaDeTrabajo = carpetaDeTrabajo.getParentFile();
		actualiza();
	}
	@Override
	public void creaCarpeta(String arg0) throws GestionFicherosException {
		File archivo = new File(carpetaDeTrabajo,arg0);
		
		// Vamos a Hacer un bucle en el cual vamos a lanzar dos excepciones que no exista y que no se tengan permisos
		
		if (!carpetaDeTrabajo.canWrite()) {
			throw new GestionFicherosException(" No tiene permiso para crear la carpeta");
		}else if (!carpetaDeTrabajo.exists()) {
			throw new GestionFicherosException("No existe");
		}else {
			// Con la siguiente linea creamos la carpeta 
			archivo.mkdir();
			
		}
		actualiza();
	}
	@Override
	public void creaFichero(String arg0) throws GestionFicherosException {
		File archivo = new File(carpetaDeTrabajo, arg0);
		
		
	
					try {
						archivo.createNewFile();
					} catch (IOException e) {
						if (!carpetaDeTrabajo.canWrite()) {
							throw new GestionFicherosException(" No tiene permiso para crear la carpeta");
						}else if (!carpetaDeTrabajo.exists()) {
							throw new GestionFicherosException("No existe");
						}
						e.printStackTrace();
					}
					actualiza();
				}
				
		
	}
	@Override
	public void elimina(String arg0) throws GestionFicherosException {
		
		File archivo = new File(carpetaDeTrabajo, arg0);
		
		
		// Vamos a Hacer un bucle en el cual vamos a lanzar dos excepciones que no exista y que no se tengan permisos
		
				if (!carpetaDeTrabajo.canWrite()) {
					throw new GestionFicherosException(" No tiene permiso para eliminar");
				}else if (!carpetaDeTrabajo.exists()) {
					throw new GestionFicherosException("No existe");
				}else if(!archivo.exists()){
					throw new GestionFicherosException("No existe el archivo");
				}else {
		// Se elimina el archivo 
					archivo.delete();
					
				}
				actualiza();
	}
	@Override
	public void entraA(String arg0) throws GestionFicherosException {
		// TODO Auto-generated method stub
		File file = new File(carpetaDeTrabajo,arg0);
		
		
		
		if(!file.canRead()) {
			throw new GestionFicherosException("ERROR. No tienes permisos");
		}
		if(!file.exists()) {
			throw new GestionFicherosException("ERROR. el directorio "+file.getAbsolutePath()+" no existe");
		}
		if(!file.isDirectory()) {
			throw new GestionFicherosException("ERROR. el directorio "+file.getAbsolutePath()+" pero no se ha encontrado");
		}
		carpetaDeTrabajo = file;
		actualiza();
	}
	@Override
	public int getColumnas() {
		
		return columnas;
	}
	@Override
	public Object[][] getContenido() {
		// TODO Auto-generated method stub
		return contenido;
	}
	@Override
	public String getDireccionCarpeta() {
		// TODO Auto-generated method stub
		return carpetaDeTrabajo.getAbsolutePath();
		
	}
	@Override
	public String getEspacioDisponibleCarpetaTrabajo() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getEspacioTotalCarpetaTrabajo() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public int getFilas() {
		// TODO Auto-generated method stub
		return filas;
	}
	@Override
	public FormatoVistas getFormatoContenido() {
		// TODO Auto-generated method stub
		return formatoVistas;
	}
	@Override
	public String getInformacion(String arg0) throws GestionFicherosException {
		// TODO Auto-generated method stub
		File archivo = new File(carpetaDeTrabajo,arg0);
		Date data = new Date (archivo.lastModified());
		StringBuilder cadena = new StringBuilder();
		
		// Creacion de los Throws para capturar los errores, si el archivo existe y si se puede o no leer
		if (!archivo.exists()) throw new GestionFicherosException("No existe el archivo");
		if (!archivo.canRead()) throw new GestionFicherosException("No se puede leer el archivo");
		
		
	
		cadena.append("-----------INFROMACION DEL FICHERO----------"+"\n");
		
		// Mediante el isDirectory comprobamos si el archivo es un directorio y le decimos que nos devuelva si es un directorio o si es un archivo mediante un boolean
		cadena.append(" Tipo de archivo --> "+ (archivo.isDirectory() ? "Fichero \n" : "Directorio \n"));
		cadena.append("Nombre: "+archivo.getName());
		cadena.append("Ubicaci�n del archivo :"+ archivo.getAbsolutePath()+"\n");
		//Convertimos el tipo date en un string mediante el metodo toString implementado en la clase Date
		cadena.append("�ltima fecha de modificaci�n: "+ data.toString()+"\n");
		
		// con el totalSpace obtenemos el espacio total que haya en el archivo tipo File, si es tipo File
		if(archivo.isFile()) {
			cadena.append("Tama�o en bytes :" + archivo.getTotalSpace()+"\n");
			
		}else {
			// Si no es un tipo File continuara en esta parte del bucle dado que indicara que es un directorio daremos los datos requeridos para los directorios
			cadena.append("Elementos que contiene el directorio "+archivo.list().length + "\n" );
			cadena.append("Espacio libre del Directorio: "+archivo.getFreeSpace()+" KB");
			cadena.append("Espacio Disponible del Directorio: "+archivo.getUsableSpace()+ " KB" );
			cadena.append("Espacio Total del Directorio: "+archivo.getTotalSpace()+" KB");
		}
		
		
		
		
		
		
		return cadena.toString();
	}
	@Override
	public boolean getMostrarOcultos() {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public String getNombreCarpeta() {
		// TODO Auto-generated method stub
		return carpetaDeTrabajo.getName();
	}
	@Override
	public TipoOrden getOrdenado() {
		// TODO Auto-generated method stub
		return ordenado;
	}
	@Override
	public String[] getTituloColumnas() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public long getUltimaModificacion(String arg0) throws GestionFicherosException {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public String nomRaiz(int arg0) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public int numRaices() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public void renombra(String arg0, String arg1) throws GestionFicherosException {
		// creamos la variable de un objeto File
		File archivo = new File(carpetaDeTrabajo, arg0);
		
		
		// Vamos a Hacer un bucle en el cual vamos a lanzar dos excepciones que no exista y que no se tengan permisos
		
		if (!carpetaDeTrabajo.canWrite()) {
			throw new GestionFicherosException(" No tiene permiso de escritura");
		}else if (!carpetaDeTrabajo.exists()) {
			throw new GestionFicherosException("No existe");
		}else {
			// creamos el objeto file para renombrarlo
			File archivo2 = new File(carpetaDeTrabajo, arg1);
			archivo.renameTo(archivo2);
			
		}
		
		actualiza();
		
	}
	@Override
	public boolean sePuedeEjecutar(String arg0) throws GestionFicherosException {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean sePuedeEscribir(String arg0) throws GestionFicherosException {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean sePuedeLeer(String arg0) throws GestionFicherosException {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public void setColumnas(int arg0) {
		columnas = arg0;
		
	}
	@Override
	public void setDirCarpeta(String arg0) throws GestionFicherosException {
		// TODO Auto-generated method stub
		File file = new File(arg0);
		
		
		
		if(!file.canRead()) {
			throw new GestionFicherosException("ERROR. No tienes permisos");
		}
		if(!file.exists()) {
			throw new GestionFicherosException("ERROR. el directorio "+file.getAbsolutePath()+" no existe");
		}
		if(!file.isDirectory()) {
			throw new GestionFicherosException("ERROR. el directorio "+file.getAbsolutePath()+" pero no se ha encontrado");
		}
		carpetaDeTrabajo = file;
		actualiza();
	}
	@Override
	public void setFormatoContenido(FormatoVistas arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void setMostrarOcultos(boolean arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void setOrdenado(TipoOrden arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void setSePuedeEjecutar(String arg0, boolean arg1) throws GestionFicherosException {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void setSePuedeEscribir(String arg0, boolean arg1) throws GestionFicherosException {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void setSePuedeLeer(String arg0, boolean arg1) throws GestionFicherosException {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void setUltimaModificacion(String arg0, long arg1) throws GestionFicherosException {
		// TODO Auto-generated method stub
		
	}
	
}
